# NE-501 Multi Pump Controller v1.0.0

Windows desktop controller for a New Era NE-501 OEM syringe-pump network.

## Final release features

- Four independent pump panels by default: 00, 01, 02, 03.
- COM port selection; default COM4 / 19200 baud / 8N1.
- Syringe inside-diameter write/read verification before flow controls unlock.
- Independent steady flow rate, direction, continuous/finite volume settings.
- Prime volume with five software speed presets: Max 100%, High 50%, Medium 25%, Low 10%, Min 5%.
- Prime rate automatically calculated from verified syringe diameter.
- Automatic Prime -> steady-flow program sequence.
- APPLY & VERIFY read-back before RUN is enabled.
- Individual RUN/STOP and Active-group Apply/RUN/STOP.
- EMERGENCY STOP ALL for every configured pump address.
- Status-aware STOP handling for NE501 V3.934.
- Scrollable four-panel workspace and UI scale selector.
- CSV command/response logging.
- Simulation mode.
- Strict ETX-complete packet handling and response-address validation.
- External `config.json` beside the EXE is supported and validated.

## Quick start

1. Install the USB-RS232 Windows driver.
2. Close WinPumpTerm and any serial monitor.
3. Run `setup_dev.bat` once on a development machine.
4. Run `run_dev.bat`.
5. Select the COM port and Connect.
6. Scan pumps.
7. SET & VERIFY DIAMETER for each pump.
8. Configure Prime / steady flow.
9. APPLY & VERIFY.
10. Select Active pumps and RUN.

See `User_Manual_Traditional_Chinese.pdf` for the full operating procedure.

## Tests

Run:

```text
run_tests.bat
```

Build scripts also cancel the build if tests fail.

## Windows build

Development environment:

```text
setup_dev.bat
```

ONEDIR:

```text
build_onedir.bat
```

ONEFILE:

```text
build_onefile.bat
```

Final release folder:

```text
build_final_release.bat
```

The final release script creates:

```text
release\NE501_Multi_Pump_Controller_v1.0.0\
```

with the EXE, config file, manuals, and final review.

## Logs

Windows log directory:

```text
%LOCALAPPDATA%\NE501_Multi_Pump_Controller\logs\
```

## Important limitations

- Prime presets limit commanded pump speed; they do not measure or limit microfluidic pressure.
- EMERGENCY STOP ALL depends on the PC/serial communication path and is not a physical emergency-stop circuit.
- The controller uses Basic-mode RS-232 communication.
- GUI state reflects the latest command response; the app does not continuously poll every pump.

See `FINAL_REVIEW.md` for the full release review.


## Documentation

English:
- `Pre_Installation_Setup_Guide_English.pdf` / `.docx` - beginner guide from unboxing through first successful software connection.
- `User_Manual_English.pdf` / `.docx` - complete software operation manual.

Traditional Chinese:
- `Pre_Installation_Setup_Guide_Traditional_Chinese.pdf` / `.docx` - 前置作業與首次連線指南。
- `User_Manual_Traditional_Chinese.pdf` / `.md` - 軟體操作說明書。
