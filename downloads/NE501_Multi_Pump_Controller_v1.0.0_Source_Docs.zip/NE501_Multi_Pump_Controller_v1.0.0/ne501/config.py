from __future__ import annotations

import json
from pathlib import Path
import sys
from typing import Any


DEFAULT_CONFIG: dict[str, Any] = {
    "port": "COM4",
    "baudrate": 19200,
    "addresses": [0, 1, 2, 3],
    "window_title": "NE-501 Multi Pump Controller v1.0.0",
}

VALID_BAUDRATES = {300, 1200, 2400, 9600, 19200}


def resource_path(relative: str) -> Path:
    """Return the bundled resource path for source or PyInstaller builds."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))
    return base / relative


def external_config_path() -> Path:
    """Return an editable config.json beside the source tree or final EXE."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent / "config.json"
    return Path(__file__).resolve().parents[1] / "config.json"


def _validated_config(candidate: dict[str, Any]) -> dict[str, Any]:
    config = dict(DEFAULT_CONFIG)

    port = candidate.get("port")
    if isinstance(port, str) and port.strip():
        config["port"] = port.strip()

    baudrate = candidate.get("baudrate")
    try:
        baudrate_int = int(baudrate)
    except (TypeError, ValueError):
        baudrate_int = DEFAULT_CONFIG["baudrate"]
    if baudrate_int in VALID_BAUDRATES:
        config["baudrate"] = baudrate_int

    addresses = candidate.get("addresses")
    if isinstance(addresses, list):
        try:
            normalized = [int(value) for value in addresses]
        except (TypeError, ValueError):
            normalized = []
        if normalized and len(normalized) == len(set(normalized)) and all(0 <= value <= 99 for value in normalized):
            config["addresses"] = normalized

    title = candidate.get("window_title")
    if isinstance(title, str) and title.strip():
        config["window_title"] = title.strip()

    return config


def load_config() -> dict[str, Any]:
    """Load validated configuration.

    A config.json beside the final EXE takes precedence so COM defaults and pump
    addresses remain editable after a ONEFILE build. If it is absent, use the
    bundled config.json.
    """
    candidates = [external_config_path(), resource_path("config.json")]
    seen: set[Path] = set()
    for path in candidates:
        try:
            resolved = path.resolve()
        except OSError:
            resolved = path
        if resolved in seen:
            continue
        seen.add(resolved)
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(loaded, dict):
            return _validated_config(loaded)
    return dict(DEFAULT_CONFIG)
