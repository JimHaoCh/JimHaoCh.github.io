# NE-501 Multi Pump Controller v1.0.0

這是已完成四台 NE-501 實機測試的最終版專案。

初次開箱、接線、Address 設定、驅動/Python 安裝與第一次啟動，請先閱讀：

- `Pre_Installation_Setup_Guide_Traditional_Chinese.pdf`
- `Pre_Installation_Setup_Guide_Traditional_Chinese.docx`

日常軟體操作請閱讀：

- `User_Manual_Traditional_Chinese.pdf`
- `User_Manual_Traditional_Chinese.md`

## 主要功能

- 預設 Pump address 00、01、02、03。
- 預設 COM4 / 19200 baud / 8N1，COM 可由 GUI 選擇。
- 每台獨立 Syringe inside diameter，寫入後讀回確認。
- Diameter 未驗證前鎖定 Prime / Flow / Active。
- 每台獨立 Prime volume、Prime speed、steady flow rate、方向與 steady target volume。
- Prime 5 檔：Max / High / Medium / Low / Min。
- Prime rate 依已驗證的針筒內徑自動換算。
- Prime 完成後自動切換 steady flow。
- APPLY & VERIFY 讀回 Pumping Program 後才開放 RUN。
- 個別 RUN / STOP。
- Active 群組 Apply / RUN / STOP。
- EMERGENCY STOP ALL。
- UI size 85% / 100% / 115% / 130%。
- CSV 通訊紀錄。
- Simulation mode。

## 最終版強化

v1.0.0 在已驗證的 v0.2.3 操作邏輯上增加：

- RS-232 回應必須完整收到 ETX 才接受。
- 回應 Pump address 必須與送出的 address 一致。
- 最終 EXE 同資料夾的 `config.json` 可修改預設 COM 與 address，並進行格式驗證。
- `Target volume` 名稱改為 `Steady target volume`，避免與 Prime volume 混淆。
- 清理開發 cache 與舊版文件。

## 建置

第一次：

```text
setup_dev.bat
```

測試：

```text
run_tests.bat
```

最終 EXE + 文件資料夾：

```text
build_final_release.bat
```

## 安全提醒

Prime 速度比例不代表微流體壓力限制。本程式沒有壓力感測器。第一次使用新管路或晶片，建議先從 Min / Low Prime 評估。

`EMERGENCY STOP ALL` 是 RS-232 軟體停止，應保留實體可斷電的方法。

詳細限制請閱讀 `FINAL_REVIEW.md`。
