# Changelog

## v1.0.0

Final hardware-validated release.

- Preserved four independent pump panels and Active group selection.
- Preserved verified syringe-diameter workflow.
- Preserved Prime -> steady-flow automatic program sequence.
- Preserved five Prime speed presets: Max, High, Medium, Low, Min.
- Preserved user-adjustable UI scaling and scrollable pump workspace.
- Added strict ETX-complete response handling.
- Added pump response-address validation.
- Added validated external `config.json` support beside the final EXE.
- Clarified `Steady target volume` wording.
- Updated Windows version metadata to 1.0.0.
- Added final review document, Chinese operation manual, test script, and final release build script.

## Development history

The v0.1.x and v0.2.x development series established COM communication, multi-pump addressing, diameter verification, flow programming, Prime operation, firmware-specific STOP handling, UI scaling, and Prime speed presets. v1.0.0 is the cleaned and hardened release derived from the successfully tested v0.2.3 baseline.
