@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] The virtual environment does not exist.
  echo Run setup_dev.bat first.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" -m unittest discover -s tests -v
if errorlevel 1 (
  echo [ERROR] Tests failed. Build cancelled.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --windowed ^
  --name "NE501_Multi_Pump_Controller" ^
  --icon "assets\ne501.ico" ^
  --add-data "assets;assets" ^
  --add-data "config.json;." ^
  --version-file "version_info.txt" ^
  main.py

if errorlevel 1 (
  echo [ERROR] Build failed.
  pause
  exit /b 1
)

echo.
echo ONEDIR build completed:
echo dist\NE501_Multi_Pump_Controller\NE501_Multi_Pump_Controller.exe
pause
