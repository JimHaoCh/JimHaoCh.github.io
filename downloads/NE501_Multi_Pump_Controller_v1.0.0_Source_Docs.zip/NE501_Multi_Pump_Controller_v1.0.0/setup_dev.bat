@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PYTHON_LAUNCH="

where py >nul 2>nul
if not errorlevel 1 (
  py -3.12 -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)" >nul 2>nul
  if not errorlevel 1 set "PYTHON_LAUNCH=py -3.12"
)

if not defined PYTHON_LAUNCH (
  where python >nul 2>nul
  if not errorlevel 1 (
    python -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)" >nul 2>nul
    if not errorlevel 1 set "PYTHON_LAUNCH=python"
  )
)

if not defined PYTHON_LAUNCH if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set PYTHON_LAUNCH="%LocalAppData%\Programs\Python\Python312\python.exe"
if not defined PYTHON_LAUNCH if exist "%ProgramFiles%\Python312\python.exe" set PYTHON_LAUNCH="%ProgramFiles%\Python312\python.exe"

if not defined PYTHON_LAUNCH (
  echo [ERROR] Python 3.12 64-bit was not found.
  echo Download the Windows installer ^(64-bit^) from:
  echo https://www.python.org/downloads/release/python-31210/
  echo During installation, select "Add python.exe to PATH" and install the Python Launcher.
  echo Then close this window, open a new Command Prompt, and run setup_dev.bat again.
  pause
  exit /b 1
)

echo Using: %PYTHON_LAUNCH%

if not exist ".venv\Scripts\python.exe" (
  echo Creating the Python virtual environment...
  %PYTHON_LAUNCH% -m venv .venv
  if errorlevel 1 (
    echo [ERROR] Failed to create .venv.
    pause
    exit /b 1
  )
)

echo Updating pip...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 (
  echo [ERROR] Failed to update pip.
  pause
  exit /b 1
)

echo Installing project packages...
".venv\Scripts\python.exe" -m pip install -r requirements.txt -r requirements-build.txt
if errorlevel 1 (
  echo [ERROR] Package installation failed.
  pause
  exit /b 1
)

echo.
echo Setup completed successfully.
echo Run run_dev.bat to start the application.
pause
