# Project status: v1.0.0 FINAL

- Target hardware: New Era NE-501 OEM syringe pumps
- Default serial port: COM4 (user-selectable)
- Serial protocol: RS-232 Basic mode, 19200 baud / 8N1
- Default pump addresses: 00, 01, 02, 03
- Four independent GUI panels
- English GUI with Traditional Chinese user manual
- Syringe inside-diameter write/read verification
- Independent steady flow settings per pump
- Prime volume + five Prime speed presets
- Automatic Prime -> steady-flow transition
- Active pump group selection
- Individual and group RUN / STOP
- Emergency STOP ALL command
- Program read-back verification before RUN
- CSV command/response logging
- Simulation mode
- UI scale selector and scrollable panel workspace
- PyInstaller ONEDIR / ONEFILE / final-release build scripts
- Strict ETX packet completion and response-address validation

Hardware testing of the four-pump system and Prime workflow has been completed by the user. See `FINAL_REVIEW.md` and `User_Manual_Traditional_Chinese.pdf` for operational limits and release notes.
