@echo off
setlocal EnableExtensions
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] The virtual environment does not exist.
  echo Run setup_dev.bat first.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" -m compileall -q main.py ne501 ui tests
if errorlevel 1 (
  echo [ERROR] Python compile check failed.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" -m unittest discover -s tests -p "test_*.py" -v
if errorlevel 1 (
  echo [ERROR] Tests failed.
  pause
  exit /b 1
)

echo.
echo All compile checks and tests passed.
pause
