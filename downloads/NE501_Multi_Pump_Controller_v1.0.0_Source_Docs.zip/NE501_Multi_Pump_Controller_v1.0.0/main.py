from __future__ import annotations

import sys

from PySide6.QtCore import QSettings
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from ne501.config import load_config, resource_path
from ui.main_window import MainWindow
from ui.style import build_stylesheet


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("NE501 Multi Pump Controller")
    app.setOrganizationName("NE501Controller")
    app.setStyle("Fusion")

    settings = QSettings("NE501Controller", "NE501 Multi Pump Controller")
    try:
        ui_scale = float(settings.value("ui_scale", 1.0))
    except (TypeError, ValueError):
        ui_scale = 1.0
    app.setStyleSheet(build_stylesheet(ui_scale))

    icon_path = resource_path("assets/ne501.ico")
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    window = MainWindow(load_config())
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
