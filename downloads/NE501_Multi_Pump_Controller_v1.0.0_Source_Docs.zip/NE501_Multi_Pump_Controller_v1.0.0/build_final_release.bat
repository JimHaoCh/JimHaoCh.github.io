@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "APP=NE501_Multi_Pump_Controller"
set "VERSION=1.0.0"
set "RELEASE_DIR=release\%APP%_v%VERSION%"

if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] The virtual environment does not exist.
  echo Run setup_dev.bat first.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" -m compileall -q main.py ne501 ui tests
if errorlevel 1 (
  echo [ERROR] Python compile check failed. Build cancelled.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" -m unittest discover -s tests -p "test_*.py" -v
if errorlevel 1 (
  echo [ERROR] Tests failed. Build cancelled.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name "%APP%" ^
  --icon "assets\ne501.ico" ^
  --add-data "assets;assets" ^
  --add-data "config.json;." ^
  --version-file "version_info.txt" ^
  main.py

if errorlevel 1 (
  echo [ERROR] PyInstaller build failed.
  pause
  exit /b 1
)

if exist "%RELEASE_DIR%" rmdir /s /q "%RELEASE_DIR%"
mkdir "%RELEASE_DIR%"
copy /y "dist\%APP%.exe" "%RELEASE_DIR%\%APP%.exe" >nul
copy /y "config.json" "%RELEASE_DIR%\config.json" >nul
copy /y "README.md" "%RELEASE_DIR%\README.md" >nul
copy /y "README_Traditional_Chinese.md" "%RELEASE_DIR%\README_Traditional_Chinese.md" >nul
copy /y "User_Manual_Traditional_Chinese.md" "%RELEASE_DIR%\User_Manual_Traditional_Chinese.md" >nul
if exist "User_Manual_Traditional_Chinese.pdf" copy /y "User_Manual_Traditional_Chinese.pdf" "%RELEASE_DIR%\User_Manual_Traditional_Chinese.pdf" >nul
if exist "Pre_Installation_Setup_Guide_Traditional_Chinese.pdf" copy /y "Pre_Installation_Setup_Guide_Traditional_Chinese.pdf" "%RELEASE_DIR%\Pre_Installation_Setup_Guide_Traditional_Chinese.pdf" >nul
if exist "Pre_Installation_Setup_Guide_Traditional_Chinese.docx" copy /y "Pre_Installation_Setup_Guide_Traditional_Chinese.docx" "%RELEASE_DIR%\Pre_Installation_Setup_Guide_Traditional_Chinese.docx" >nul
if exist "User_Manual_English.pdf" copy /y "User_Manual_English.pdf" "%RELEASE_DIR%\User_Manual_English.pdf" >nul
if exist "User_Manual_English.docx" copy /y "User_Manual_English.docx" "%RELEASE_DIR%\User_Manual_English.docx" >nul
if exist "Pre_Installation_Setup_Guide_English.pdf" copy /y "Pre_Installation_Setup_Guide_English.pdf" "%RELEASE_DIR%\Pre_Installation_Setup_Guide_English.pdf" >nul
if exist "Pre_Installation_Setup_Guide_English.docx" copy /y "Pre_Installation_Setup_Guide_English.docx" "%RELEASE_DIR%\Pre_Installation_Setup_Guide_English.docx" >nul
copy /y "FINAL_REVIEW.md" "%RELEASE_DIR%\FINAL_REVIEW.md" >nul
copy /y "CHANGELOG.md" "%RELEASE_DIR%\CHANGELOG.md" >nul
copy /y "VERSION" "%RELEASE_DIR%\VERSION" >nul

echo.
echo Final release completed:
echo %RELEASE_DIR%
echo.
echo The target PC still requires the USB-RS232 Windows driver.
pause
